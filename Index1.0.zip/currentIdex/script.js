// Import commands from command.js
// Ensure command.js is included before script.js in your HTML file

// List of commands
const commands = {
    help: "Displays all available commands",
    command1: "Executes Command 1",
    command2: "Executes Command 2",
    command3: "Executes Command 3"
};

// Function to handle 'help' command
function handleHelpCommand() {
    console.log("Available commands:");
    Object.keys(commands).forEach(command => {
        console.log(`${command}: ${commands[command]}`);
    });
}

// Listen for console input
function listenConsoleInput() {
    console.log("Type 'help' for a list of available commands.");

    // Listen for console input
    window.addEventListener('keydown', function(event) {
        if (event.key === "Enter") {
            const input = event.target.value.trim();
            if (input === "help") {
                handleHelpCommand();
            }
        }
    });
}

// Call the function to start listening for console input
listenConsoleInput();
