const { exec } = require('child_process');
const express = require('express');
const app = express();

// Define route to handle 'refresh' command
app.get('/refresh', (req, res) => {
    // Execute Lua script using 'script1.lua'
    exec('lua script1.lua', (error, stdout, stderr) => {
        if (error) {
            console.error(`Error executing Lua script: ${error.message}`);
            res.status(500).send('Internal Server Error');
            return;
        }
        console.log(`Lua script output: ${stdout}`);
        res.send('Page Refreshed Successfully');
    });
});

// Start the server
const PORT = 80;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
