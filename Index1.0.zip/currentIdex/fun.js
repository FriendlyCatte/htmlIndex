// Function to play audio file based on argument
function playSound(argument) {
    if (argument === "true") {
        const audio = new Audio("assets/Lie-Detector-True.mp3");
        audio.play();
    } else if (argument === "lie") {
        const audio = new Audio("assets/Lie-Detector-False.mp3");
        audio.play();
    } else {
        console.log("Please enter a valid argument ('true' or 'lie').");
    }
}

// Listen for user input
document.getElementById('userInput').addEventListener('keydown', function(event) {
    if (event.key === "Enter") {
        const input = event.target.value.trim().toLowerCase();
        const parts = input.split(" "); // Split input into parts by space
        const command = parts[0]; // First part is the command
        const argument = parts[1]; // Second part is the argument (if any)

        if (command === "playSound") {
            if (argument) {
                playSound(argument);
            } else {
                console.error("Please enter a valid argument ('true' or 'lie').");
            }
        } else {
            console.error("Command not recognized.");
        }

event.target.value = ''; // Clear input field after processing
    }
});