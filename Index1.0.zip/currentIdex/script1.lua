-- Lua script to refresh the page
io.write("Refreshing the page...\n")
os.execute("echo 'window.location.reload()' | xclip -selection c
