// display in console that the script is loaded
console.log("Javascript Command By Velocity")
console.log("Command Has Been Loaded")
function great() {
    // display if on pc
    prompt("Hello")
    // display in console
    console.log("Hello")
}

function info() {
    // Version
    let versionString = "1.0";
    let [major, minor] = versionString.split('.').map(Number);
    //
    console.log("---- INFO ----")
    console.log(`Version (Major): ${major}`)
    console.log(`Version (Minor): ${minor}`)
}

function copyright() {
    // body...
    console.log("Copyright Velocity 2024-2025")
}

function help() {
    console.log("Command 1: great")
    console.log("Command 2: info")
    console.log("Command 3: copyright")
}